from datetime import timedelta
import pandas as pd

from data_loader import load_data
from cashflow import check_safety, to_date


# ============================================================
# CONFIGURATION
# ============================================================

FORECAST_DAYS = 90


# ============================================================
# SAFE AMOUNT CALCULATION
# ============================================================

def calculate_safe_amount(
    profile,
    events,
    request_date,
    requested_amount,
):
    """
    Find the largest amount that can be paid immediately
    while keeping the balance above the minimum requirement
    throughout the 90-day forecast.

    Uses binary search for efficiency.
    """

    requested_amount = float(
        requested_amount
    )

    # --------------------------------------------------------
    # First check whether full amount is safe
    # --------------------------------------------------------

    full_check = check_safety(
        profile=profile,
        events=events,
        request_date=request_date,
        payment_amount=requested_amount,
        forecast_days=FORECAST_DAYS,
    )

    if full_check["safe"]:
        return {
            "safe_amount": requested_amount,
            "lowest_balance": full_check[
                "lowest_balance"
            ],
            "minimum_balance": full_check[
                "minimum_balance"
            ],
            "full_amount_safe": True,
        }

    # --------------------------------------------------------
    # Full amount is NOT safe.
    # Find maximum safe amount.
    # --------------------------------------------------------

    low = 0.0
    high = requested_amount

    # Binary search
    for _ in range(60):

        mid = (
            low + high
        ) / 2

        result = check_safety(
            profile=profile,
            events=events,
            request_date=request_date,
            payment_amount=mid,
            forecast_days=FORECAST_DAYS,
        )

        if result["safe"]:
            low = mid
        else:
            high = mid

    final_check = check_safety(
        profile=profile,
        events=events,
        request_date=request_date,
        payment_amount=low,
        forecast_days=FORECAST_DAYS,
    )

    return {
        "safe_amount": round(
            low,
            2
        ),
        "lowest_balance": final_check[
            "lowest_balance"
        ],
        "minimum_balance": final_check[
            "minimum_balance"
        ],
        "full_amount_safe": False,
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print("Loading dataset...")
    print()

    data = load_data()

    requests = data["requests"]
    profiles = data["profiles"]
    events = data["events"]

    # --------------------------------------------------------
    # Test request
    # --------------------------------------------------------

    request_id = "request_26"

    request = requests[
        requests["request_id"]
        == request_id
    ].iloc[0]

    user_id = request[
        "user_id"
    ]

    profile = profiles[
        profiles["user_id"]
        == user_id
    ].iloc[0]

    user_events = events[
        events["user_id"]
        == user_id
    ].copy()

    request_date = to_date(
        request["request_date"]
    )

    requested_amount = float(
        request["requested_amount"]
    )

    # --------------------------------------------------------
    # Calculate
    # --------------------------------------------------------

    print(
        f"Calculating safe amount for "
        f"{request_id}..."
    )

    result = calculate_safe_amount(
        profile=profile,
        events=user_events,
        request_date=request_date,
        requested_amount=requested_amount,
    )

    # --------------------------------------------------------
    # Display
    # --------------------------------------------------------

    print()
    print("=" * 70)
    print("AFFORDABILITY ANALYSIS")
    print("=" * 70)

    print(
        f"Request ID       : {request_id}"
    )

    print(
        f"User ID          : {user_id}"
    )

    print(
        f"Request Date     : {request_date}"
    )

    print(
        f"Requested Amount : "
        f"{requested_amount:.2f}"
    )

    print(
        f"Current Balance  : "
        f"{float(profile['current_available_balance']):.2f}"
    )

    print(
        f"Minimum Balance  : "
        f"{float(profile['minimum_balance_to_keep']):.2f}"
    )

    print(
        f"Safe Amount      : "
        f"{result['safe_amount']:.2f}"
    )

    print(
        f"Lowest Projected : "
        f"{result['lowest_balance']:.2f}"
    )

    print("=" * 70)

    if result["full_amount_safe"]:

        print(
            "✅ FULL AMOUNT IS SAFE TO PAY NOW"
        )

    elif result["safe_amount"] > 0:

        print(
            "⚠️ PARTIAL AMOUNT IS SAFE TO PAY NOW"
        )

    else:

        print(
            "❌ NO AMOUNT IS SAFE TO PAY NOW"
        )

    print("=" * 70)


if __name__ == "__main__":
    main()