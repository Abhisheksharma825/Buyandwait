import pandas as pd
import os


def main():

    root = os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )

    output_path = os.path.join(
        root,
        "output.csv"
    )

    sample_path = os.path.join(
        root,
        "dataset",
        "sample_requests.csv"
    )

    output = pd.read_csv(output_path)
    sample = pd.read_csv(sample_path)

    print("=" * 70)
    print("SAMPLE REQUEST COMPARISON")
    print("=" * 70)

    print(
        f"\nGenerated output rows: {len(output)}"
    )

    print(
        f"Sample rows: {len(sample)}"
    )

    # ---------------------------------------------
    # Find common request IDs
    # ---------------------------------------------

    common_ids = sorted(
        set(output["request_id"])
        &
        set(sample["request_id"])
    )

    print(
        f"Common sample requests: {len(common_ids)}"
    )

    if not common_ids:
        print(
            "\nNo common request IDs found."
        )
        return

    generated = output[
        output["request_id"].isin(common_ids)
    ].copy()

    expected = sample[
        sample["request_id"].isin(common_ids)
    ].copy()

    # ---------------------------------------------
    # Merge
    # ---------------------------------------------

    merged = generated.merge(
        expected,
        on="request_id",
        how="inner",
        suffixes=("_generated", "_expected")
    )

    # ---------------------------------------------
    # Compare important fields
    # ---------------------------------------------

    fields = [
        "amount_safe_to_pay",
        "affordability_status",
        "recommended_payment_method",
        "payment_plan",
        "earliest_date_for_full_payment",
        "spending_changes_needed"
    ]

    print("\n" + "-" * 70)
    print("FIELD ACCURACY")
    print("-" * 70)

    for field in fields:

        gen_col = field + "_generated"
        exp_col = field + "_expected"

        if (
            gen_col not in merged.columns
            or
            exp_col not in merged.columns
        ):
            print(
                f"{field}: column unavailable"
            )
            continue

        if field == "amount_safe_to_pay":

            generated_values = pd.to_numeric(
                merged[gen_col],
                errors="coerce"
            )

            expected_values = pd.to_numeric(
                merged[exp_col],
                errors="coerce"
            )

            matches = (
                (generated_values - expected_values)
                .abs()
                <= 0.01
            )

        else:

            generated_values = (
                merged[gen_col]
                .fillna("")
                .astype(str)
                .str.strip()
            )

            expected_values = (
                merged[exp_col]
                .fillna("")
                .astype(str)
                .str.strip()
            )

            matches = (
                generated_values
                == expected_values
            )

        count = int(
            matches.sum()
        )

        total = len(matches)

        accuracy = (
            count / total * 100
            if total
            else 0
        )

        print(
            f"{field}: "
            f"{count}/{total} "
            f"({accuracy:.1f}%)"
        )

    # ---------------------------------------------
    # Status comparison
    # ---------------------------------------------

    print("\n" + "-" * 70)
    print("STATUS COMPARISON")
    print("-" * 70)

    status_comparison = pd.crosstab(
        merged["affordability_status_generated"],
        merged["affordability_status_expected"],
        rownames=["Generated"],
        colnames=["Expected"]
    )

    print(
        status_comparison
    )

    # ---------------------------------------------
    # Payment method comparison
    # ---------------------------------------------

    print("\n" + "-" * 70)
    print("PAYMENT METHOD COMPARISON")
    print("-" * 70)

    method_comparison = pd.crosstab(
        merged["recommended_payment_method_generated"],
        merged["recommended_payment_method_expected"],
        rownames=["Generated"],
        colnames=["Expected"]
    )

    print(
        method_comparison
    )

    # ---------------------------------------------
    # Show mismatches
    # ---------------------------------------------

    status_mismatch = (
        merged[
            "affordability_status_generated"
        ]
        !=
        merged[
            "affordability_status_expected"
        ]
    )

    method_mismatch = (
        merged[
            "recommended_payment_method_generated"
        ]
        !=
        merged[
            "recommended_payment_method_expected"
        ]
    )

    mismatches = merged[
        status_mismatch
        |
        method_mismatch
    ]

    print("\n" + "-" * 70)
    print("IMPORTANT MISMATCHES")
    print("-" * 70)

    if mismatches.empty:

        print(
            "No status/payment-method mismatches!"
        )

    else:

        display_columns = [
            "request_id",
            "affordability_status_generated",
            "affordability_status_expected",
            "recommended_payment_method_generated",
            "recommended_payment_method_expected"
        ]

        print(
            mismatches[
                display_columns
            ].to_string(index=False)
        )

    # ---------------------------------------------
    # Save comparison
    # ---------------------------------------------

    comparison_path = os.path.join(
        root,
        "sample_comparison.csv"
    )

    merged.to_csv(
        comparison_path,
        index=False
    )

    print(
        f"\nDetailed comparison saved to:"
    )

    print(
        comparison_path
    )

    print("\n" + "=" * 70)
    print("COMPARISON COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()